﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmBeer
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.BtnCreateFile = New System.Windows.Forms.Button()
        Me.BtnWriteToFile = New System.Windows.Forms.Button()
        Me.BtnReadToFile = New System.Windows.Forms.Button()
        Me.txtDisplay = New System.Windows.Forms.TextBox()
        Me.lblHighestRegion = New System.Windows.Forms.Label()
        Me.txtHighestRegion = New System.Windows.Forms.TextBox()
        Me.BtnDisplay = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'BtnCreateFile
        '
        Me.BtnCreateFile.Location = New System.Drawing.Point(12, 12)
        Me.BtnCreateFile.Name = "BtnCreateFile"
        Me.BtnCreateFile.Size = New System.Drawing.Size(187, 42)
        Me.BtnCreateFile.TabIndex = 0
        Me.BtnCreateFile.Text = "Create File"
        Me.BtnCreateFile.UseVisualStyleBackColor = True
        '
        'BtnWriteToFile
        '
        Me.BtnWriteToFile.Location = New System.Drawing.Point(12, 60)
        Me.BtnWriteToFile.Name = "BtnWriteToFile"
        Me.BtnWriteToFile.Size = New System.Drawing.Size(187, 42)
        Me.BtnWriteToFile.TabIndex = 1
        Me.BtnWriteToFile.Text = "Write To File"
        Me.BtnWriteToFile.UseVisualStyleBackColor = True
        '
        'BtnReadToFile
        '
        Me.BtnReadToFile.Location = New System.Drawing.Point(12, 108)
        Me.BtnReadToFile.Name = "BtnReadToFile"
        Me.BtnReadToFile.Size = New System.Drawing.Size(187, 42)
        Me.BtnReadToFile.TabIndex = 2
        Me.BtnReadToFile.Text = "Read From File"
        Me.BtnReadToFile.UseVisualStyleBackColor = True
        '
        'txtDisplay
        '
        Me.txtDisplay.Location = New System.Drawing.Point(215, 12)
        Me.txtDisplay.Multiline = True
        Me.txtDisplay.Name = "txtDisplay"
        Me.txtDisplay.Size = New System.Drawing.Size(365, 211)
        Me.txtDisplay.TabIndex = 3
        '
        'lblHighestRegion
        '
        Me.lblHighestRegion.AutoSize = True
        Me.lblHighestRegion.Location = New System.Drawing.Point(12, 238)
        Me.lblHighestRegion.Name = "lblHighestRegion"
        Me.lblHighestRegion.Size = New System.Drawing.Size(86, 26)
        Me.lblHighestRegion.TabIndex = 4
        Me.lblHighestRegion.Text = "Highest Average" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Rating Region"
        '
        'txtHighestRegion
        '
        Me.txtHighestRegion.Location = New System.Drawing.Point(105, 238)
        Me.txtHighestRegion.Name = "txtHighestRegion"
        Me.txtHighestRegion.Size = New System.Drawing.Size(100, 20)
        Me.txtHighestRegion.TabIndex = 5
        '
        'BtnDisplay
        '
        Me.BtnDisplay.Location = New System.Drawing.Point(12, 156)
        Me.BtnDisplay.Name = "BtnDisplay"
        Me.BtnDisplay.Size = New System.Drawing.Size(187, 42)
        Me.BtnDisplay.TabIndex = 6
        Me.BtnDisplay.Text = "Display Details of all the regions"
        Me.BtnDisplay.UseVisualStyleBackColor = True
        '
        'frmBeer
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(592, 277)
        Me.Controls.Add(Me.BtnDisplay)
        Me.Controls.Add(Me.txtHighestRegion)
        Me.Controls.Add(Me.lblHighestRegion)
        Me.Controls.Add(Me.txtDisplay)
        Me.Controls.Add(Me.BtnReadToFile)
        Me.Controls.Add(Me.BtnWriteToFile)
        Me.Controls.Add(Me.BtnCreateFile)
        Me.Name = "frmBeer"
        Me.Text = "Regional Beer"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents BtnCreateFile As Button
    Friend WithEvents BtnWriteToFile As Button
    Friend WithEvents BtnReadToFile As Button
    Friend WithEvents txtDisplay As TextBox
    Friend WithEvents lblHighestRegion As Label
    Friend WithEvents txtHighestRegion As TextBox
    Friend WithEvents BtnDisplay As Button
End Class
