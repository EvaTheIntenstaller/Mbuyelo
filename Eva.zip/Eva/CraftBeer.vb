﻿Option Infer Off
Option Explicit On
Option Strict On


Public Class CraftBeer
    Private _ID As Integer
    Private _Name As String
    Private _Price As Double
    Private _Rating As Integer

    Public Function CraftBeerValue() As Double
        Dim Ans As Double
        Ans = _Price / _Rating
        If Ans < 0 Then
            Return 0
        Else
            Return Ans
        End If
    End Function
    Public Property Name As String
        Get
            Return _Name
        End Get
        Set(value As String)
            _Name = value
        End Set
    End Property
    Public Property ID As Integer
        Get
            Return _ID
        End Get
        Set(value As Integer)
            _ID = ValidateId(value)
        End Set
    End Property

    Public Property Price As Double
        Get
            Return _Price
        End Get
        Set(value As Double)
            If value < 0 Then
                _Price = 0
            Else
                _Price = value
            End If
        End Set
    End Property

    Public Property Rating() As Integer
        Get '
            Return _Rating
        End Get
        Set(value As Integer)
            If value < 0 Then
                _Rating = 0
            Else
                _Rating = value
            End If
        End Set
    End Property
    Private Function ValidateId(Value As Integer) As Integer
        If Value <= 450 And Value >= 100 Then
            Return Value
        Else
            Return 100
        End If
    End Function
    Public Function Output() As String
        Dim Ans As String
        Ans = "ID: " & CStr(_ID) & Environment.NewLine
        Ans &= "Name:" & _Name & Environment.NewLine
        Ans &= "Price: " & Format(_Price, "##.##") & Environment.NewLine
        Ans &= "Rating: " & CStr(_Rating) & Environment.NewLine
        Ans &= "Value: " & Format(CraftBeerValue(), "##.##") & Environment.NewLine
        Return Ans
    End Function
End Class
