﻿Option Strict On
Option Infer Off
Option Explicit On

Imports System.IO
Imports System.Runtime.Serialization.Formatters.Binary
Public Class frmBeer
    Private FileStream1 As FileStream
    Private BinaryFormatter As BinaryFormatter
    Private FileName As String
    Private BinaryReader As BinaryReader
    Private BinaryWriter As BinaryWriter
    Private Num_Recs As Integer = 27 'Num Of Recs 
    Private Const Rec_Size As Integer = 47 'Max Bytes
    Private Prime As Integer = 23 ' Closest To The Number Of Recs
    Private Jregions() As JRegion
    Private Number As Integer

    Private Function ValidateId(Value As Integer) As Integer
        If Value <= 450 And Value >= 100 Then
            Return Value
        Else
            MsgBox("The ID you have Instatiated has already been used Or its value is too small ,enter another one",, "Invalid ID")
        End If
    End Function
    Private Structure CraftBeerRec
        Public Id As Integer '4 Bytes
        <VBFixedString(35)> Public Name As String '2 * 35 Bytes
        Public Price As Double ' 8 Bytes
    End Structure


    'The hash function
    Private Function Hash(Key As Integer) As Integer
        Return Key Mod Prime
    End Function

    Private BlankRec As CraftBeerRec

    Private Sub CreateBlankRec()
        BlankRec.Id = -1
        BlankRec.Name = LSet("", 35)
        BlankRec.Price = -1
    End Sub
    Private Sub CreateFile()
        FileName = InputBox("Enter the name of the file ", "file name")
        FileName = FileName & ".txt"
        FileStream1 = New FileStream(FileName, FileMode.Create, FileAccess.Write)
        BinaryWriter = New BinaryWriter(FileStream1)
        FileStream1.SetLength(Rec_Size * Num_Recs)
        For i As Integer = 1 To Num_Recs
            FileStream1.Seek(i * Rec_Size, SeekOrigin.Begin)
            BinaryWriter.Write(BlankRec.Id)
            BinaryWriter.Write(BlankRec.Name)
            BinaryWriter.Write(BlankRec.Price)
        Next
        FileStream1.Flush()
        FileStream1.Close()
        FileStream1 = Nothing
        BinaryWriter = Nothing
        MsgBox("File Was Successfully Created",, "File Created!")
    End Sub

    Private Sub WriteToFile(TempBeer As CraftBeerRec)
        FileStream1 = New FileStream(FileName, FileMode.Open, FileAccess.Write)
        BinaryWriter = New BinaryWriter(FileStream1)
        FileStream1.Seek(Hash(TempBeer.Id) * Rec_Size, SeekOrigin.Begin)
        BinaryWriter.Write(TempBeer.Id)
        BinaryWriter.Write(TempBeer.Name)
        BinaryWriter.Write(TempBeer.Price)

        FileStream1.Flush()
        FileStream1.Close()
        FileStream1 = Nothing
        BinaryWriter = Nothing
        MsgBox("Task was Sucessfull",, "Data Saved")
    End Sub
    Private Function ReadTofile(ID As Integer) As CraftBeerRec
        Dim TempCraftBeer As CraftBeerRec
        FileStream1 = New FileStream(FileName, FileMode.Open, FileAccess.Read)
        BinaryReader = New BinaryReader(FileStream1)
        FileStream1.Seek(Hash(ID) * Rec_Size, SeekOrigin.Begin)
        TempCraftBeer.Id = BinaryReader.ReadInt32()
        If TempCraftBeer.Id = -1 Then
            FileStream1.Close()
            BinaryReader = Nothing
            FileStream1 = Nothing
            MsgBox("The Id you have entered is invalid",, "Invalid Id")
        Else
            TempCraftBeer.Name = BinaryReader.ReadString()
            TempCraftBeer.Price = BinaryReader.ReadDouble()
            Return TempCraftBeer
        End If
    End Function

    Private Sub frmBeer_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        CreateBlankRec()
    End Sub

    Private Sub BtnCreateFile_Click(sender As Object, e As EventArgs) Handles BtnCreateFile.Click
        CreateFile()
    End Sub

    Private Sub BtnWriteToFile_Click(sender As Object, e As EventArgs) Handles BtnWriteToFile.Click
        Dim TempBeerCraft As CraftBeerRec

        Number = CInt(InputBox("Enter the number of regions", "Region Number"))
        ReDim Jregions(Number)
        For i As Integer = 1 To Number
            Dim Name As String = InputBox("Enter the name of the region", "Region Name")
            Dim NumberBeers As Integer = CInt(InputBox("Enter the number of beers that were crafted" & Name, "Number of Beers"))
            Jregions(i) = New JRegion(Name, NumberBeers)
            For a As Integer = 1 To NumberBeers
                Jregions(i).CraftBeer(a) = New CraftBeer()
                Jregions(i).CraftBeer(a).ID = CInt(InputBox("Enter the ID of the Beer,no." & CStr(a), "ID of Beer"))
                TempBeerCraft.Id = Jregions(i).CraftBeer(a).ID
                Jregions(i).CraftBeer(a).Name = InputBox("Enter The name of the beer , no." & CStr(a), "Name of the beer")
                TempBeerCraft.Name = Jregions(i).CraftBeer(a).Name
                Jregions(i).CraftBeer(a).Price = CDbl(InputBox("Enter The Price of the beer , no." & CStr(a), "Beer Price"))
                TempBeerCraft.Price = Jregions(i).CraftBeer(a).Price
                Jregions(i).CraftBeer(a).Rating = CInt(InputBox("Enter The Rating of the beer , no:" & CStr(a), "Rating of the beer"))
            Next a
            Jregions(i).CalAveRating()
            WriteToFile(TempBeerCraft)
        Next i
    End Sub

    Private Sub BtnReadToFile_Click(sender As Object, e As EventArgs) Handles BtnReadToFile.Click
        txtDisplay.Clear()
        Dim ID As Integer = CInt(InputBox("Enter The Id of The region you wish view its details", "Region Details"))
        Dim TempCraftBeer As CraftBeerRec
        TempCraftBeer = ReadTofile(ID)
        txtDisplay.Text &= "ID: " & CStr(TempCraftBeer.Id) & Environment.NewLine
        txtDisplay.Text &= "Name: " & TempCraftBeer.Name & Environment.NewLine
        txtDisplay.Text &= "Price: " & Format(TempCraftBeer.Price, "##.##") & Environment.NewLine
    End Sub

    Private Sub BtnDisplay_Click(sender As Object, e As EventArgs) Handles BtnDisplay.Click
        txtDisplay.Clear()
        Dim Index As Integer
        Dim Ans As Double = Jregions(1).CalAveRating
        For i As Integer = 1 To Number
            If Ans < Jregions(i).CalAveRating Then
                Ans = Jregions(i).CalAveRating
                Index = i
            End If
            ' find the region with the highest rating
            txtDisplay.Text &= Jregions(i).OutPut() & Environment.NewLine
            txtHighestRegion.Text = Jregions(Index).Name
        Next
    End Sub

    Private Sub txtHighestRegion_TextChanged(sender As Object, e As EventArgs) Handles txtHighestRegion.TextChanged

    End Sub



End Class
