﻿Option Explicit On
Option Infer Off
Option Strict On
Public Class JRegion
    Private _Name As String
    Private _NumBeers As Integer '
    Private _CraftBeer() As CraftBeer

    Public Sub New(Name As String, NumBeers As Integer)
        _Name = Name
        _NumBeers = NumBeers
        ReDim _CraftBeer(NumBeers)

    End Sub

    Public ReadOnly Property Name As String
        Get
            Return _Name
        End Get
    End Property
    Public Property NumBeers() As Integer '
        Get
            Return _Numbeers

        End Get
        Set(value As Integer)
            If value < 0 Then
                _Numbeers = 0
            Else
                _Numbeers = value
            End If
        End Set
    End Property
    Public Property CraftBeer(index As Integer) As CraftBeer
        Get
            Return _CraftBeer(index)
        End Get
        Set(value As CraftBeer)
            _CraftBeer(index) = value
        End Set
    End Property

    Public Function CalAveRating() As Double
        Dim Ans As Double
        For i As Integer = 1 To _NumBeers
            Ans += _CraftBeer(i).Rating
        Next
        Return Ans / _Numbeers
    End Function


    Public Function OutPut() As String
        Dim Ans As String
        Ans = "Region Name: " & _Name & Environment.NewLine
        For i As Integer = 1 To _NumBeers
            Ans &= "Beer No." & CStr(i) & "Details:" & Environment.NewLine
            Ans &= _CraftBeer(i).Output() & Environment.NewLine
        Next
        Ans &= "Average Rating: " & CStr(CalAveRating()) & Environment.NewLine
        Return Ans
    End Function
End Class
